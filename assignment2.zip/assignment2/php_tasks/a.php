#!/usr/bin/php
<?php

////////////////////////////////////////////////////////////////////////////////
//                                TASK E                                      //
////////////////////////////////////////////////////////////////////////////////
//
// The toprank script takes in 3 or 4 commandline arguments:
// ./toprank K StartYear EndYear
// Or:
// ./toprank Genres K StartYear EndYear
// Where Genres is a list of genres separated by '&', K is the top K movies
// Ranked by IMDB score and then by the number of votes
// (both in descending order) between (and including) StartYear and EndYear,
// With 1 <= K <= 1000, 1900 < StartYear <= EndYear < 2020 and your program
// Will not be tested with a list of more than 8 genres. We interpret '&' as
// conjunction, i.e., the selected movies shall contain all the specified
// Genres. When Genres is not provided (when your program takes in 3 arguments),
// Perform the same ranking but on movies with any genres. Do not include any
// Movie titles with empty year.
//

// include the common PHP code file
require("a2.php");

// PROGRAM BODY BEGINS

$usage = "Usage: $argv[0] Start Goal";
$db = dbConnect(DB_CONNECTION);

// Check arguments
if (count($argv) != 3){ 
  exit("$usage\n");
}

$start = $argv[1];
$goal = $argv[2];

$q = "SELECT id from actor where name ILIKE '$start' LIMIT 1;";
$r = dbQuery($db, mkSQL($q, $start));
$t = dbNext($r);
if(empty($t[0])){
	exit("$start is not an actor\n");
}
$start = $t[0];

$q = "SELECT id from actor where name ILIKE '$goal' LIMIT 1;";
$r = dbQuery($db, mkSQL($q, $goal));
$t = dbNext($r);
if(empty($t[0])){
	exit("$goal is not an actor\n");
}
$goal = $t[0];

if($start == $goal){
	return;
}

$q = "SELECT * from pathfinding_actors;";
$r = dbQuery($db, mkSQL($q));
// Iterate through the results and create graph which will be used for path finding
$graph = array();
while (($t = dbNext($r))) {
  if(empty($graph[$t[0]])){
  	$graph[$t[0]] = array();
  }
  if(empty($graph[$t[6]])){
  	$graph[$t[6]] = array();  
  }
  if(empty($graph[$t[0]][$t[6]])){
  	 $graph[$t[0]][$t[6]] = array();
  }
  if(empty($graph[$t[6]][$t[0]])){
  	 $graph[$t[6]][$t[0]] = array();
  }
  if(empty($t[4])){
  	array_push($graph[$t[0]][$t[6]], $t[2]);
  	array_push($graph[$t[6]][$t[0]], $t[2]);
  }else{
  	array_push($graph[$t[0]][$t[6]], array($t[2],$t[4]));
  	array_push($graph[$t[6]][$t[0]], array($t[2],$t[4]));
  }
}
$visited = array();
$to_visit = array();
//print_r($graph);

array_push($visited, $start);
$shortest_path_length = -1;
$found_shortest_paths = false;
$all_shortest_paths = array();
$ida = 1;


while($ida < 8){
	$current = array($start);
	array_push($to_visit,$current);
	while(sizeof($to_visit) > 0){
		echo sizeof($to_visit)."\n";
		$current = array_pop($to_visit);
		$new_array = $current;
		$inspection_node = end($new_array);
		if($inspection_node == $goal && !in_array($to_visit, $current)){
			//print_r($current);
			if($shortest_path_length == -1){
				//print_r($current);
				array_push($all_shortest_paths, $current);
				$shortest_path_length = sizeof($current);
			}else if($shortest_path_length == sizeof($current)){
				array_push($all_shortest_paths, $current);
			}
		}
		if(sizeof($current) < $ida){
			foreach($graph[$inspection_node] as $node => $val){
				if(!in_array($node, $current)){
					$new_array = $current;
					array_push($new_array, $node);
					array_push($to_visit, $new_array);
				}
			} 
		}
	}
	$to_visit = array();
	$ida++;
	//echo "pushing depth to $ida\n";
	if($ida > $shortest_path_length && $shortest_path_length != -1){
		break;
	}
}
//echo "done\n";
//print_r($all_shortest_paths);

$full_shortest_paths = array();
foreach($all_shortest_paths as $paths => $path){
	$array_of_movies = array();
	for($i = 0; $i < sizeof($path) - 1; $i++){
		//echo actor_from_id($path[$i])." and ".actor_from_id($path[$i + 1])."\n";
		$movie_list = $graph[$path[$i]][$path[$i + 1]];
		//print_r($movie_list);
		for($j = 0; $j < sizeof($movie_list); $j++){
			//print_r($movie_list[$j]);
			//echo movie_from_id($movie_list[$j][0])."\n";
			if(!in_array(array($movie_list[$j][0], $path[$i] , $path[$i + 1]), $array_of_movies)){
				array_push($array_of_movies, array($movie_list[$j][0], $path[$i] , $path[$i + 1]));
			}
		}
	}
	$paths = BFS_ALL_NODES($array_of_movies, $graph, $start, $goal);
	array_push($full_shortest_paths, array($path,$array_of_movies));
	//echo "new path\n";
	break;
}
$i = 1;
$to_print = array();
//print_r($full_shortest_paths);

function BFS_ALL_NODES($arr1, $graph, $start, $goal){
	//print_r($arr1);
	$new_graph = array();
	//print_R($arr1);
	for($i = 0; $i < sizeof($arr1); $i++){
		$final_paths = array($arr1[$i][0]);
		if($arr1[$i][1] == $start){
			//$new_final_path = array();
		}
	}
	//print_r($new_graph);
}

/*
foreach($full_shortest_paths as $movies => $actors_movies){
	//$unique_movies[1] = array_unique($actors_movies[1]);
	$final_printout = "";
	for($i = 0; $i < sizeof($actors_movies[0]) - 1;$i++){
		echo movie_from_id($actors_movies[1][$i])."\n";
		//echo $actors_movies[[$i]."\n";
		$actor1 = actor_from_id($actors_movies[0][$i]);
		$actor2 = actor_from_id($actors_movies[0][$i + 1]);
		//$titlee = movie_from_id($actors_movies[1][$i]);;
		//echo "$actor1 was in with $actor2; ";
	}
	//$i++;
	echo "\n";	
			//$i++;

	//$i++;
	//echo "\n";
}
echo "\n";
*/
?>
