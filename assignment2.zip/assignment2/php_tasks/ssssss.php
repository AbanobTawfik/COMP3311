#!/usr/bin/php
<?php

////////////////////////////////////////////////////////////////////////////////
//                                TASK E                                      //
////////////////////////////////////////////////////////////////////////////////
//
// The toprank script takes in 3 or 4 commandline arguments:
// ./toprank K StartYear EndYear
// Or:
// ./toprank Genres K StartYear EndYear
// Where Genres is a list of genres separated by '&', K is the top K movies
// Ranked by IMDB score and then by the number of votes
// (both in descending order) between (and including) StartYear and EndYear,
// With 1 <= K <= 1000, 1900 < StartYear <= EndYear < 2020 and your program
// Will not be tested with a list of more than 8 genres. We interpret '&' as
// conjunction, i.e., the selected movies shall contain all the specified
// Genres. When Genres is not provided (when your program takes in 3 arguments),
// Perform the same ranking but on movies with any genres. Do not include any
// Movie titles with empty year.
//

// include the common PHP code file
require("a2.php");

// PROGRAM BODY BEGINS

$usage = "Usage: $argv[0] Start Goal";
$db = dbConnect(DB_CONNECTION);

// Check arguments
if (count($argv) != 3){ 
  exit("$usage\n");
}

$start = $argv[1];
$goal = $argv[2];

$q = "SELECT id from actor where name ILIKE '$start' LIMIT 1;";
$r = dbQuery($db, mkSQL($q, $start));
$t = dbNext($r);
if(empty($t[0])){
	exit("$start is not an actor\n");
}
$start = $t[0];

$q = "SELECT id from actor where name ILIKE '$goal' LIMIT 1;";
$r = dbQuery($db, mkSQL($q, $goal));
$t = dbNext($r);
if(empty($t[0])){
	exit("$goal is not an actor\n");
}
$goal = $t[0];

if($start == $goal){
	return;
}

$q = "SELECT * from pathfinding_actors;";
$r = dbQuery($db, mkSQL($q));
// Iterate through the results and create graph which will be used for path finding
$graph = array();
while (($t = dbNext($r))) {
  if(empty($graph[$t[0]])){
  	$graph[$t[0]] = array();
  }
  if(empty($graph[$t[6]])){
  	$graph[$t[6]] = array();  
  }
  if(empty($graph[$t[0]][$t[6]])){
  	 $graph[$t[0]][$t[6]] = array();
  }
  if(empty($graph[$t[6]][$t[0]])){
  	 $graph[$t[6]][$t[0]] = array();
  }
  array_push($graph[$t[0]][$t[6]], $t[2]);
  array_push($graph[$t[6]][$t[0]], $t[2]);
}
//print_r($graph);
$visited = array();
$to_visit = array();
//print_r($graph);

$max_depth = false;
$all_shortest_paths = array();
$ida = 1;

while($ida < 8){
	$current = array($start);
	array_push($to_visit,array($start, $current,array()));
	while(sizeof($to_visit) > 0){
		$current = array_pop($to_visit);
		$inspection_node = $current[0];

		if($inspection_node == $goal){
			foreach($current[1] as $actor){
				foreach($current[2] as $movie){
					$name = actor_from_id($actor);
					$title = movie_from_id($movie);
					echo "$name was in $title\n";
					//echo "$actor was in $movie\n";
				}
			}
			array_push($all_shortest_paths, array($current[1], $current[2]));
			$max_depth = true;
		}

		if(sizeof($current[1]) < $ida){
			foreach($graph[$inspection_node] as $node => $val){
				if(!in_array($node, $current[1])){
					$new_array = $current[1];
					array_push($new_array, $node);
					$new_array2 = $current[2];
					array_push($new_array2, $val[1]);
					array_push($to_visit, array($node, $new_array, $new_array2));
				}
			} 
		}
	}
	$to_visit = array();
	$ida++;
	echo "pushing depth to $ida\n";
	if($max_depth){
		break;
	}
}

echo "done\n";
?>
