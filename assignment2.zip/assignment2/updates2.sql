-- COMP3311 19s1 Assignment 2
--
-- updates.sql
--
-- Written by Riley Sutton (z5164867), Apr 2019

--  This script takes a "vanilla" imdb database (a2.db) and
--  make all of the changes necessary to make the databas
--  work correctly with your PHP scripts.
--  
--  Such changes might involve adding new views,
--  PLpgSQL functions, triggers, etc. Other changes might
--  involve dropping or redefining existing
--  views and functions (if any and if applicable).
--  You are not allowed to create new tables for this assignment.
--  
--  Make sure that this script does EVERYTHING necessary to
--  upgrade a vanilla database; if we need to chase you up
--  because you forgot to include some of the changes, and
--  your system will not work correctly because of this, you
--  will lose half of your assignment 2 final mark as penalty.
--

--  This is to ensure that there is no trailing spaces in movie titles,
--  as some tasks need to perform full title search.
UPDATE movie SET title = TRIM (title);

--  Add your code below
--

CREATE OR REPLACE VIEW conn(pre_actor_id, movie_id, post_actor_id) AS
    SELECT a0.actor_id, m0.movie_id, m0.actor_id
    FROM acting AS a0
    JOIN acting AS m0 ON a0.movie_id = m0.movie_id
    WHERE a0.actor_id != m0.actor_id;

CREATE OR REPLACE FUNCTION path_deg1(id INTEGER)
RETURNS TABLE (a0 actor.id%TYPE, m1 movie.id%TYPE, a1 actor.id%TYPE)
AS
$$
SELECT conn.pre_actor_id, conn.movie_id, conn.post_actor_id
FROM conn
WHERE conn.pre_actor_id = id;
$$ LANGUAGE SQL;

CREATE OR REPLACE FUNCTION path_deg2(id INTEGER)
RETURNS TABLE (a0 actor.id%TYPE, m1 movie.id%TYPE, a1 actor.id%TYPE, m2 movie.id%TYPE, a2 actor.id%TYPE)
AS
$$
SELECT path_deg1.a0, path_deg1.m1, conn.pre_actor_id, conn.movie_id, conn.post_actor_id
FROM path_deg1(id)
INNER JOIN conn ON conn.pre_actor_id = path_deg1.a1
                       AND conn.movie_id != path_deg1.m1
                       AND conn.pre_actor_id != path_deg1.a0
                       AND conn.post_actor_id != path_deg1.a0 AND conn.post_actor_id != path_deg1.a1
$$ LANGUAGE SQL;

CREATE OR REPLACE FUNCTION path_deg3(id INTEGER)
RETURNS TABLE (a0 actor.id%TYPE, m1 movie.id%TYPE, a1 actor.id%TYPE, m2 movie.id%TYPE, a2 actor.id%TYPE, m3 movie.id%TYPE, a3 actor.id%TYPE)
AS
$$
SELECT path_deg2.a0, path_deg2.m1, path_deg2.a1, path_deg2.m2, conn.pre_actor_id, conn.movie_id, conn.post_actor_id
FROM path_deg2(id)
INNER JOIN conn ON conn.pre_actor_id = path_deg2.a2
                       AND conn.movie_id != path_deg2.m2 AND conn.movie_id != path_deg2.m1
                       AND conn.pre_actor_id != path_deg2.a1 AND conn.pre_actor_id != path_deg2.a0
                       AND conn.post_actor_id != path_deg2.a2 AND conn.post_actor_id != path_deg2.a1 AND conn.post_actor_id != path_deg2.a0
$$ LANGUAGE SQL;
